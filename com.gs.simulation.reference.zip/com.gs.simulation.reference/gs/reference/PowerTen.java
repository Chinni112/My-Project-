package com.gs.reference;

public class PowerTen {
    public static boolean isPowerOfTen(int n) {

        if (n <= 0) {
            return false;
        }
        while (n % 10 == 0) {
            n /= 10;
        }


        return n == 1;
    }

    public static void main(String[] args) {
        int num1 = 1000;
        int num2 = 50;
        int num3 = 1;
        int num4 = 10;

        System.out.println(num1 + " is a power of 10: " + isPowerOfTen(num1));
        System.out.println(num2 + " is a power of 10: " + isPowerOfTen(num2));
        System.out.println(num3 + " is a power of 10: " + isPowerOfTen(num3));
        System.out.println(num4 + " is a power of 10: " + isPowerOfTen(num4));
    }
}
