package com.gs.reference;

public class IntegerMissing {
    public static int findMissingNumber(int[] array) {
        int actualSum = 0;
        int n=array.length+1;
        int expectedSum = n * (n + 1) / 2;
        for (int num : array) {
            actualSum += num;
        }
        return expectedSum - actualSum;
    }

    public static void main(String[] args) {
        int[] array = {1,3,4,5,6};
        int missingNumber = findMissingNumber(array);
        System.out.println("The missing integer is: " + missingNumber);
    }
}
