package com.gs.reference;
import  java.util.*;
public class WaveSort {

    public static void waveSort(int[] arr) {
        Arrays.sort(arr);
        // Swap adjacent elements
        for (int posi = 0; posi < arr.length - 1; posi += 2) {
            // Swap arr[i] and arr[i+1]
            int temp = arr[posi];
            arr[posi] = arr[posi + 1];
            arr[posi + 1] = temp;
        }
    }

    public static void main(String[] args) {
        int[] arr = {10, 5, 6, 3, 2, 20, 100, 80};
        waveSort(arr);

        // Print the wave sorted array
        System.out.println("Wave sorted array: " + Arrays.toString(arr));
    }
}
