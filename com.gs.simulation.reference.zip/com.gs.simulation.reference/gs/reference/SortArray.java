package com.gs.reference;

public class SortArray {
    public static int minSortArray(int[] input) {
        // Handle empty array case
        if (input == null || input.length == 0) {
            throw new IllegalArgumentException("Array must not be empty.");
        }

        int minArr = input[0];
        for (int num : input) {
            minArr = Math.min(minArr, num);
        }
        return minArr;
    }

    public static void main(String[] args) {
        int array[]={21,2,3,3,55,4};
       int result= minSortArray(array);
        System.out.println(result);
    }
}
