package com.gs.reference;

import  java.util.*;

public class SmallIntger {
    public static int findSmallestInteger(int[] arr) {
        HashSet<Integer> set = new HashSet<>();
        for (int num : arr) {
            set.add(num);
        }
        int smallestMissing = 0;
        while (set.contains(smallestMissing)) {
            smallestMissing++;
        }

        return smallestMissing;
    }

    public static void main(String[] args) {
        int[] arr1 = {1, 2, 3, 4};
        int[] arr2 = {0, 1, 3, 4};
        System.out.println(findSmallestInteger(arr1));
        System.out.println(findSmallestInteger(arr2));
    }
}
