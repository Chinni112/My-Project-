package com.gs.newsimulation;

import  java.util.*;

public class PascalTriangle {
    public List<List<Integer>> generate(int num) {
        List<List<Integer>> triangle = new ArrayList<List<Integer>>();

        for (int i = 0; i < num; i++) {
            List<Integer> row = new ArrayList<Integer>();
            for (int j = 0; j <= i; j++) {
                if (j == 0 || j == i) {
                    row.add(1);
                } else {
                    int value = triangle.get(i - 1).get(j - 1) + triangle.get(i - 1).get(j);
                    row.add(value);
                }
            }
            triangle.add(row);
        }

        return triangle;
    }

    public static void main(String[] args) {
        PascalTriangle pt = new PascalTriangle();
        int numRows = 5;
        List<List<Integer>> result = pt.generate(numRows);
        for (List<Integer> row : result) {
            System.out.println(row);
        }
    }
}
